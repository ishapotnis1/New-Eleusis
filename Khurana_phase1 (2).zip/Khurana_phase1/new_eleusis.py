#Isha Potnis (NE12771)
#Nitika Khurana (BH42137)
#Komal Sharan XQ71651
#Srishty Saha (RY85017)
# Trivial functions to be used in the important test functions
# All require a nonempty string as the argument

def is_suit(s):
    """Test if parameter is one of Club, Diamond, Heart, Spade"""
    return s in "CDHS"

def is_color(s):
    """Test if parameter is one of Black or Red"""
    return s in "BR"

def is_value(s):
    """Test if parameter is a number or can be interpreted as a number"""
    return s.isdigit() or (len(s) == 1 and s[0] in "AJQK")

def is_card(s):
    """Test if parameter is a value followed by a suit"""
    return is_suit(s[-1]) and is_value(s[:len(s) - 1])

##def split_card(card):
##    """Returns a value, suit tuple of a card"""
##    length = len(card)
##    return (card[:length - 1], card[-1])

def value_to_number(name):
    """Given the "value" part of a card, returns its numeric value"""
    values = [None, 'A', '2', '3', '4', '5', '6',
              '7', '8', '9', '10', 'J', 'Q', 'K']
    return values.index(name)

def number_to_value(number):
    """Given the numeric value of a card, returns its "value" name"""
    values = [None, 'A', '2', '3', '4', '5', '6',
              '7', '8', '9', '10', 'J', 'Q', 'K']
    return values[number]

# Important functions

def suit(card):
    """Returns the suit of a card"""
    return card[-1]

def color(card):
    """Returns the color of a card"""
    return {'C':'B', 'D':'R', 'H':'R', 'S':'B'}.get(suit(card))

def value(card):
    """Returns the numeric value of a card or card value as an integer 1..13"""
    prefix = card[:len(card) - 1]
    names = {'A':1, 'J':11, 'Q':12, 'K':13}
    if prefix in names:
        return names.get(prefix)
    else:
        return int(prefix)

def is_royal(card):
    """Tests if a card is royalty (Jack, Queen, or King)"""
    return value(card) > 10

def equal(a, b):
    """Tests if two suits, two colors, two cards, or two values are equal."""
    return a == b

def less(a, b):
    """Tests if a is less than b, where a and b are suits, cards,
       colors, or values. For suits: C < D < H < S. For colors,
       B < R. For cards, suits are considered first, then values.
       Values are compared numerically."""
    if is_card(a):
        if suit(a) != suit(b):
            return suit(a) < suit(b)
        else:
            return value(a) < value(b)
    elif is_value(a):
        return value_to_number(a) < value_to_number(b)
    else:
        return a < b

def greater(a, b):
    """The opposite of less"""
    return less(b, a)

def plus1(x):
    """Returns the next higher value, suit, or card in a suit;
       must be one. If a color, returns the other color"""
    if is_value(x):
        assert value_to_number(x) < 13
        return number_to_value(value_to_number(x) + 1)
    elif is_suit(x):
        assert x != 'S'
        return "CDHS"["CDHS".index(x) + 1]
    elif is_card(x):
        return number_to_value(value(x) + 1) + suit(x)
    elif is_color(x):
        return "BR"["BR".index(x) - 1]
    
def minus1(x):
    """Returns the next lower value, suit, or card in a suit;
       must be one. If a color, returns the other color"""
    if is_value(x):
        assert value_to_number(x) > 1
        return number_to_value(value_to_number(x) - 1)
    elif is_suit(x):
        assert x != 'C'
        return "CDHS"["CDHS".index(x) - 1]
    elif is_card(x):
        return number_to_value(value(x) - 1) + suit(x)
    elif is_color(x):
        return "BR"["BR".index(x) - 1]

def even(card):
    """Tells if the card's numeric value is even"""
    return value(card) % 2 == 0

def odd(card):
    """Tells if the card's numeric value is odd"""
    return value(card) % 2 != 0

# Logic functions

def andf(a, b, cards):
    """Declares AND as a function; not implemented here"""
    pass

def orf(a, b, cards):
    """Declares OR as afunction; not implemented here"""
    pass

def notf(a, cards):
    """Declares NOT as afunction; not implemented here"""
    pass

def iff(condition, then_part, else_part, cards):    
    """Declares IF_THEN_ELSE as a function; not implemented here"""
    pass

functions = [suit, color, value, is_royal, equal, less,
             greater, plus1, minus1, even, odd, andf,
             orf, notf, iff]
                  
class Tree:
    debugging = True

    def __init__(self, root, left=None, right=None, test=False):
        """Create a new Tree; default is no children"""
        self.root = root
        self.left = left
        self.right = right
        self.test = test

    def __str__(self):
        """Provide a printable representation of this Tree"""
        if self.left == None and self.right == None:
            return str(self.root)
        elif self.right == None:
            return '{}({})'.format(self.root.__name__, self.left)
        else:
            return '{}({}, {})'.format(self.root.__name__, self.left, self.right)

    def logical_value(self, x, cards):
        """This is a hack to deal with the fact that we cannot call
           x.evaluate(cards) if x is a logical value"""
        if type(x) == bool:
            return x
        else:
            evaluate(x, cards)
            
    def evaluate(self, cards):
        """Evaluate this tree with the given card values"""
        if (self.debugging): print "Evaluating:", self

        (previous2, previous, current) = cards
        f = self.root
        if f == "current":
            return current
        elif f == "previous":
            return previous
        elif f == "previous2":
            return previous2
        
        if type(f) == str or type(f) == bool:
            return f
        
        assert f in functions
        if f in [suit, color, value, is_royal, minus1, plus1, even, odd]:
            return f(self.left)
        
        elif f in [equal, less, greater]:
            return f(self.left, self.right)
        
        elif f == andf:
            left_val = self.logical_value(self.left, cards)
            if left_val:
                return self.logical_value(self.right, cards)
            return False
        elif f == orf:
            left_val = self.logical_value(self.left, cards)
            if left_val:
                return True
            return self.logical_value(self.right, cards)
        elif f == notf:
            return not self.logical_value(self.left, cards)
        elif f == iff:
            test = self.test.evaluate(cards)
            if test:
                return self.left.evaluate(cards)
            else:
                return self.right.evaluate(cards)
        
        
           
