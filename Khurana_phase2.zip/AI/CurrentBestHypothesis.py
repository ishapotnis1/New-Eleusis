#Isha Potnis (NE12771)
#Nitika Khurana (BH42137)
#Komal Sharan XQ71651
#Srishty Saha (RY85017)
from new_eleusis import *
import Main
count=0

cb={}

constraints={}
currentBestHypothesis={}
forvalidation={}
threshold=0.0

def pruning(hypothesis,correct,a1):
        k=hypothesis
        w=len(k)
        h=k.keys()
        f=[]
        q=[]
        for i in range(0,len(correct)):
                c=Main.extraction(correct[i])
                d=c.keys()
                for i in range(0,len(d)):
                        for j in range(0,len(h)):
                                if(d[i]==h[j]):
                                        if(c[d[i]]==1):
                                                f.append(d[i])
        final1=[]
        c1=Main.extraction(correct[0])
        c2=Main.extraction(correct[1])
        c3=Main.extraction(correct[2])
        d3=Main.comparator(c1,c2,c3)
        i=3
        while(i<len(correct)):
                d2=Main.comparator(c1,c2,c3)
                d1=d2.keys()
                for i1 in range(0,len(d1)):
                        for j in range(0,len(h)):
                                if(d1[i1]==h[j]):
                                        if(d2[d1[i1]]==1):
                                                q.append(d1[i1])
                c2=c1
                c3=c2
                c1=Main.extraction(correct[i])
                i=i+1
                if(i==len(correct)):
                        break
        for x in q:#pruning is_color
                        #print x
                        if x not  in final1:
                                final1.append(x)
        final=[]  
        for x in f:#pruning is_color
                if x not  in final:
                        final.append(x)
        final2=[]
        final_hypo={}
        if(len(a1)!=0):
                final2=a1.keys()        
                
        best=final+final1
        final_hypo['AND of rule']=best
        final_hypo['AND of Alternate']=final2
        if(final_hypo==None):
                 y=scientist.score(scientist.scoring,30)  #Score=30 if no hypthesis match with correct list
        return final_hypo

#main scientist function
def scientist(hypothesis,flag,correct,a1,count_iter):
        temp={}
	tempconstraints={}
	tempValidation={}
	if flag==3:
                w=pruning(currentBestHypothesis,correct,a1)
                return
        else:
                for field, possible_values in hypothesis.iteritems():
                        for a,x in possible_values.iteritems():
                                if x>0.15:
                                         currentBestHypothesis[a] = x
                                if x<0.05:
                                         constraints[a] = x
                                if x<0.15and x>0.05:
                                         forvalidation[a] = x

                return forvalidation,currentBestHypothesis
        if(count_iter==20):
                w1=pruning(currentBestHypothesis,correct,a1)
                return
                
